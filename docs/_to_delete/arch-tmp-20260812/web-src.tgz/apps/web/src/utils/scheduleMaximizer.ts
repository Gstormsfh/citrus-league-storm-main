import { ScheduleService, NHLGame } from '@/services/ScheduleService';
import { LeagueService } from '@/services/LeagueService';
import { Player } from '@/services/PlayerService';
import { getDraftCompletionDate, getFirstWeekStartDate, getCurrentWeekNumber, getWeekStartDate, getWeekEndDate } from './weekCalculator';
import { DEFAULT_TEST_DATE } from '@/utils/seasonConstants';
import { logger } from '@/utils/logger';

export interface PlayerWithSchedule extends Player {
  gamesThisWeek: number;
  gameDays: string[];
  projectedPoints?: number; // Optional weekly projected points
}

export interface WeekDates {
  weekStart: Date;
  weekEnd: Date;
}

// Cache for calculateWeekDates — prevents repeated LeagueService.getLeague() calls
// within the same session. Keyed by "leagueId:userId", TTL 60s.
const weekDatesCache = new Map<string, { result: WeekDates; timestamp: number }>();
const WEEK_DATES_CACHE_TTL = 60_000;

/**
 * Calculate week dates (calendar week or matchup week based on league)
 */
export async function calculateWeekDates(
  leagueId?: string,
  userId?: string
): Promise<WeekDates> {
  const cacheKey = `${leagueId || ''}:${userId || ''}`;
  const cached = weekDatesCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < WEEK_DATES_CACHE_TTL) {
    return cached.result;
  }

  // Test mode controlled via VITE_TEST_MODE environment variable (defaults to false)
  const TEST_MODE = import.meta.env.VITE_TEST_MODE === 'true';
  const TEST_DATE = import.meta.env.VITE_TEST_DATE || DEFAULT_TEST_DATE;

  const getTodayDate = () => {
    if (TEST_MODE) {
      const date = new Date(TEST_DATE + 'T00:00:00');
      date.setHours(0, 0, 0, 0);
      return date;
    }
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return today;
  };

  // Default to calendar week (Sunday-Saturday)
  const today = getTodayDate();
  const dayOfWeek = today.getDay();
  const daysFromSunday = dayOfWeek;
  let weekStart = new Date(today);
  weekStart.setDate(today.getDate() - daysFromSunday);
  weekStart.setHours(0, 0, 0, 0);
  let weekEnd = new Date(weekStart);
  weekEnd.setDate(weekStart.getDate() + 6);
  weekEnd.setHours(23, 59, 59, 999);

  // Try to use matchup week if user is logged in and has a league
  if (userId && leagueId) {
    try {
      const { league: leagueData, error: leagueError } = await LeagueService.getLeague(leagueId, userId);
      if (!leagueError && leagueData && leagueData.draft_status === 'completed') {
        const draftCompletionDate = getDraftCompletionDate(leagueData);
        if (draftCompletionDate) {
          const firstWeekStart = getFirstWeekStartDate(draftCompletionDate);
          const currentWeek = getCurrentWeekNumber(firstWeekStart);
          weekStart = getWeekStartDate(currentWeek, firstWeekStart);
          weekEnd = getWeekEndDate(currentWeek, firstWeekStart);
        }
      }
    } catch (error) {
      logger.warn('Could not fetch league data for matchup week calculation, using calendar week:', error);
    }
  }

  const result = { weekStart, weekEnd };
  weekDatesCache.set(cacheKey, { result, timestamp: Date.now() });
  return result;
}

/**
 * Batch fetch games for multiple teams in a SINGLE API call
 * Returns a map of team abbreviation -> games array
 */
export async function fetchGamesForTeams(
  teams: string[],
  weekStart: Date,
  weekEnd: Date
): Promise<Map<string, NHLGame[]>> {
  const uniqueTeams = [...new Set(teams)];

  if (uniqueTeams.length === 0) {
    return new Map();
  }

  try {
    // Single batch API call instead of N individual calls
    const { gamesByTeam } = await ScheduleService.getGamesForTeams(uniqueTeams, weekStart, weekEnd);
    return gamesByTeam;
  } catch (error) {
    logger.warn('Error batch fetching games for teams:', error);
    return new Map();
  }
}

/**
 * Calculate games this week and game days for a player
 */
export function calculatePlayerSchedule(
  player: Player,
  teamGamesMap: Map<string, NHLGame[]>
): { gamesThisWeek: number; gameDays: string[] } {
  const games = teamGamesMap.get(player.team) || [];
  const count = games.length;
  
  // Get day abbreviations for each game
  const gameDays = games.map(game => {
    // CRITICAL: Append 'T00:00:00' to force local-time parsing.
    // new Date("YYYY-MM-DD") parses as UTC midnight, giving wrong getDay() in MST.
    const gameDate = new Date(game.game_date.split('T')[0] + 'T00:00:00');
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    return dayNames[gameDate.getDay()];
  });

  return {
    gamesThisWeek: count,
    gameDays: [...new Set(gameDays)] // Remove duplicates
  };
}

/**
 * Calculate schedule maximizers for a list of players
 * Returns players with gamesThisWeek and gameDays added
 */
export async function calculateScheduleMaximizers(
  players: Player[],
  leagueId?: string,
  userId?: string,
  limit: number = 200
): Promise<PlayerWithSchedule[]> {
  try {
    // Limit to top players by points to reduce query load
    const topPlayers = [...players]
      .sort((a, b) => (b.points || 0) - (a.points || 0))
      .slice(0, limit);

    // Calculate week dates
    const { weekStart, weekEnd } = await calculateWeekDates(leagueId, userId);

    // Get unique teams to batch queries
    const uniqueTeams = [...new Set(topPlayers.map(p => p.team))];

    // Batch fetch games for all teams
    const teamGamesMap = await fetchGamesForTeams(uniqueTeams, weekStart, weekEnd);

    // Calculate games for each player
    const maximizers: PlayerWithSchedule[] = topPlayers.map(player => {
      const schedule = calculatePlayerSchedule(player, teamGamesMap);
      return {
        ...player,
        ...schedule
      };
    });

    // Sort by games count (descending), then by points (descending)
    maximizers.sort((a, b) => {
      if (b.gamesThisWeek !== a.gamesThisWeek) {
        return b.gamesThisWeek - a.gamesThisWeek;
      }
      return (b.points || 0) - (a.points || 0);
    });

    return maximizers;
  } catch (error) {
    logger.error('Error calculating schedule maximizers:', error);
    return [];
  }
}

/**
 * Get total NHL games per day for a date range
 * Returns a map of date string (YYYY-MM-DD) -> game count
 */
export async function getGamesPerDay(
  startDate: Date,
  endDate: Date
): Promise<Map<string, number>> {
  try {
    const { games } = await ScheduleService.getGamesForDateRange(startDate, endDate);
    
    const gamesPerDay = new Map<string, number>();
    
    games.forEach(game => {
      const gameDate = game.game_date.split('T')[0]; // Get YYYY-MM-DD
      const current = gamesPerDay.get(gameDate) || 0;
      gamesPerDay.set(gameDate, current + 1);
    });

    return gamesPerDay;
  } catch (error) {
    logger.error('Error getting games per day:', error);
    return new Map();
  }
}

/**
 * Get roster games per day (for your team's players)
 * Returns a map of date string (YYYY-MM-DD) -> game count for your roster
 */
export async function getRosterGamesPerDay(
  rosterPlayers: Player[],
  startDate: Date,
  endDate: Date
): Promise<Map<string, number>> {
  try {
    const uniqueTeams = [...new Set(rosterPlayers.map(p => p.team))];
    const teamGamesMap = await fetchGamesForTeams(uniqueTeams, startDate, endDate);
    
    const rosterGamesPerDay = new Map<string, number>();
    
    rosterPlayers.forEach(player => {
      const games = teamGamesMap.get(player.team) || [];
      games.forEach(game => {
        const gameDate = game.game_date.split('T')[0]; // Get YYYY-MM-DD
        const current = rosterGamesPerDay.get(gameDate) || 0;
        rosterGamesPerDay.set(gameDate, current + 1);
      });
    });

    return rosterGamesPerDay;
  } catch (error) {
    logger.error('Error getting roster games per day:', error);
    return new Map();
  }
}
